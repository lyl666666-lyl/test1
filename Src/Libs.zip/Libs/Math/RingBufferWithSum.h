#include "MathBase/RingBufferWithSum.h"
