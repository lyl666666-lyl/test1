#pragma once

#include "Streaming/Enum.h"

namespace Arms
{
  ENUM(Arm,
  {,
    left,
    right,
  });
}
