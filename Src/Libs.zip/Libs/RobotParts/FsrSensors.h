#pragma once

#include "Streaming/Enum.h"

namespace FsrSensors
{
  ENUM(FsrSensor,
  {,
    fl,
    fr,
    bl,
    br,
  });
}
