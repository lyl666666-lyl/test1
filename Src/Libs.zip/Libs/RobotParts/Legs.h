#pragma once

#include "Streaming/Enum.h"

namespace Legs
{
  ENUM(Leg,
  {,
    left,
    right,
  });
}
