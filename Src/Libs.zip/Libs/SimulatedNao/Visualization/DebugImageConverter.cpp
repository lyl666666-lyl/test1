/**
 * @file DebugImageConverter.cpp
 *
 * @author Felix Thielke
 * @author <a href="mailto:jesse@tzi.de">Jesse Richter-Klug</a>
 */

#include "DebugImageConverter.h"
#include "ImageProcessing/AVX.h"
#include "ImageProcessing/ColorModelConversions.h"
#include "Streaming/Global.h"

#if !defined __arm64__ && !defined __aarch64__

#include <asmjit/asmjit.h>

using namespace asmjit;

void yuvToBGRA(unsigned int size, const void* const src, void* const dest)
{
  static constexpr bool avx = _supportsAVX2;
  static const __m_auto_i yMask = _mmauto_set1_epi32(0x000000FF);
  static const __m_auto_i channelMask = _mmauto_set1_epi16(0x00FF);
  static const __m_auto_i c_128 = _mmauto_set1_epi16(128);
  static const __m_auto_i c_0 = _mmauto_setzero_si_all();
  static const __m_auto_i alpha = _mmauto_set1_epi8(static_cast<unsigned char>(0xFF));
  static const __m_auto_i scaledInvUCoeff = _mmauto_set1_epi16(static_cast<short>(static_cast<float>(1 << 14) / ColorModelConversions::uCoeff));
  static const __m_auto_i scaledInvVCoeff = _mmauto_set1_epi16(static_cast<short>(static_cast<float>(1 << 14) / ColorModelConversions::vCoeff));
  static const __m_auto_i scaledGCoeffU = _mmauto_set1_epi16(static_cast<short>(ColorModelConversions::yCoeffB / (ColorModelConversions::yCoeffG * ColorModelConversions::uCoeff) * static_cast<float>(1 << 15)));
  static const __m_auto_i scaledGCoeffV = _mmauto_set1_epi16(static_cast<short>(ColorModelConversions::yCoeffR / (ColorModelConversions::yCoeffG * ColorModelConversions::vCoeff) * static_cast<float>(1 << 15)));
  const __m_auto_i* pSrc = reinterpret_cast<const __m_auto_i*>(src);
  __m_auto_i* pDest = reinterpret_cast<__m_auto_i*>(dest);
  for(unsigned int n = (size + (avx ? 63 : 31)) / (avx ? 64 : 32); n; --n)
  {
    const __m_auto_i p0 = _mmauto_loadt_si_all<true>(pSrc++);
    const __m_auto_i p1 = _mmauto_loadt_si_all<true>(pSrc++);

    const __m_auto_i y = _mmauto_correct_256op(_mmauto_packs_epi32(_mmauto_and_si_all(_mmauto_srli_epi32(p0, 16), yMask), _mmauto_and_si_all(_mmauto_srli_epi32(p1, 16), yMask)));

    const __m_auto_i uv0 = _mmauto_sub_epi16(_mmauto_and_si_all(_mmauto_srli_si_all(p0, 1), channelMask), c_128);
    const __m_auto_i uv1 = _mmauto_sub_epi16(_mmauto_and_si_all(_mmauto_srli_si_all(p1, 1), channelMask), c_128);
    const __m_auto_i u = _mmauto_correct_256op(_mmauto_packs_epi32(_mmauto_srai_epi32(_mmauto_slli_epi32(uv0, 16), 16), _mmauto_srai_epi32(_mmauto_slli_epi32(uv1, 16), 16)));
    const __m_auto_i v = _mmauto_correct_256op(_mmauto_packs_epi32(_mmauto_srai_epi32(uv0, 16), _mmauto_srai_epi32(uv1, 16)));

    const __m_auto_i b = _mmauto_correct_256op(_mmauto_packus_epi16(_mmauto_add_epi16(y, _mmauto_slli_epi16(_mmauto_mulhrs_epi16(u, scaledInvUCoeff), 1)), c_0));
    const __m_auto_i g = _mmauto_correct_256op(_mmauto_packus_epi16(_mmauto_sub_epi16(y, _mmauto_add_epi16(_mmauto_mulhrs_epi16(u, scaledGCoeffU), _mmauto_mulhrs_epi16(v, scaledGCoeffV))), c_0));
    const __m_auto_i r = _mmauto_correct_256op(_mmauto_packus_epi16(_mmauto_add_epi16(y, _mmauto_slli_epi32(_mmauto_mulhrs_epi16(v, scaledInvVCoeff), 1)), c_0));

    if(avx)
    {
      __m_auto_i bgra0 = b;
      __m_auto_i tmp = g;
      _mmauto_unpacklohi_epi8(bgra0, tmp);
      __m_auto_i bgra1 = r;
      tmp = alpha;
      _mmauto_unpacklohi_epi8(bgra1, tmp);
      _mmauto_unpacklohi_epi16(bgra0, bgra1);
      _mmauto_storet_si_all<true>(pDest++, bgra0);
      _mmauto_storet_si_all<true>(pDest++, bgra1);
    }
    else
    {
      const __m_auto_i bg = _mmauto_unpacklo_epi8(b, g);
      const __m_auto_i ra = _mmauto_unpacklo_epi8(r, alpha);
      _mmauto_storet_si_all<true>(pDest++, _mmauto_unpacklo_epi16(bg, ra));
      _mmauto_storet_si_all<true>(pDest++, _mmauto_unpackhi_epi16(bg, ra));
    }
  }
}

void grayscaledToBGRA(const unsigned int size, const void* const src, void* const dest)
{
  static constexpr bool avx = _supportsAVX2;
  static const __m_auto_i alpha = _mmauto_set1_epi32(0xFF000000);
  const __m_auto_i* pSrc = reinterpret_cast<const __m_auto_i*>(src);
  __m_auto_i* pDest = reinterpret_cast<__m_auto_i*>(dest);
  for(unsigned int n = (size + (avx ? 31 : 15)) / (avx ? 32 : 16); n; --n)
  {
    const __m_auto_i p = _mmauto_loadt_si_all<true>(pSrc++);

    __m_auto_i pLo = p;
    __m_auto_i pHi = p;
    _mmauto_unpacklohi_epi8(pLo, pHi);

    __m_auto_i pLo2 = pLo;
    __m_auto_i pHi2 = pLo;
    _mmauto_unpacklohi_epi8(pLo2, pHi2);
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pLo2, alpha));
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pHi2, alpha));

    pLo2 = pHi;
    pHi2 = pHi;
    _mmauto_unpacklohi_epi8(pLo2, pHi2);
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pLo2, alpha));
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pHi2, alpha));
  }
}

void binaryToBGRA(const unsigned int size, const void* const src, void* const dest)
{
  static constexpr bool avx = _supportsAVX2;
  static const __m_auto_i alpha = _mmauto_set1_epi32(0xFF000000);
  const __m_auto_i* pSrc = reinterpret_cast<const __m_auto_i*>(src);
  __m_auto_i* pDest = reinterpret_cast<__m_auto_i*>(dest);
  for(unsigned int n = (size + (avx ? 31 : 15)) / (avx ? 32 : 16); n; --n)
  {
    const __m_auto_i p = _mmauto_cmpgt_epi8(_mmauto_loadt_si_all<true>(pSrc++), _mmauto_setzero_si_all());

    __m_auto_i pLo = p;
    __m_auto_i pHi = p;
    _mmauto_unpacklohi_epi8(pLo, pHi);

    __m_auto_i pLo2 = pLo;
    __m_auto_i pHi2 = pLo;
    _mmauto_unpacklohi_epi8(pLo2, pHi2);
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pLo2, alpha));
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pHi2, alpha));

    pLo2 = pHi;
    pHi2 = pHi;
    _mmauto_unpacklohi_epi8(pLo2, pHi2);
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pLo2, alpha));
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pHi2, alpha));
  }
}

void hueToBGRA(const unsigned int size, const PixelTypes::HuePixel* src, PixelTypes::BGRAPixel* dest)
{
  for(unsigned int n = size; n; src++, dest++, --n)
  {
    ColorModelConversions::fromYUVToRGB(128, static_cast<unsigned char>(static_cast<float>(std::cos(static_cast<float>(*src) * 360_deg / 256.f)) * 128.f + 128.f), static_cast<unsigned char>(static_cast<float>(std::sin(static_cast<float>(*src) * 360_deg / 256.f)) * 128.f + 128.f), dest->r, dest->g, dest->b);
    dest->a = 0xFF;
  }
}

void edge2ToBGRA(const unsigned int size, const void* const src, void* const dest)
{
  static constexpr bool avx = _supportsAVX2;
  static const __m_auto_i offset = _mmauto_set1_epi8(char(128));
  const __m_auto_i* pSrc = reinterpret_cast<const __m_auto_i*>(src);
  __m_auto_i* pDest = reinterpret_cast<__m_auto_i*>(dest);
  for(unsigned int n = (size + (avx ? 31 : 15)) / (avx ? 32 : 16); n; --n)
  {
    const __m_auto_i p = _mmauto_loadt_si_all<true>(pSrc++);
    const __m_auto_i offsetCorrected = _mmauto_abs_epi8(_mmauto_sub_epi8(p, offset));
    __m_auto_i res0 = _mmauto_slli_epi16(_mmauto_sqrt_epu16<avx>(_mmauto_slli_epi16(_mmauto_maddubs_epi16(offsetCorrected, offsetCorrected), 1)), 8);
    __m_auto_i res1 = p;
    _mmauto_unpacklohi_epi8(res0, res1);
    _mmauto_storet_si_all<true>(pDest++, res0);
    _mmauto_storet_si_all<true>(pDest++, res1);
  }

  yuvToBGRA(size * 2, dest, dest);
}

void asmReturn(x86::Assembler& a)
{
#ifdef WINDOWS
  a.pop(a.zsi());
  a.pop(a.zdi());
#endif
  a.pop(a.zbx());
  a.mov(a.zsp(), a.zbp());
  a.pop(a.zbp());
  a.ret();
}

void rgbToBGRA(x86::Assembler& a)
{
  Label constants = a.newLabel();
  Label loop = a.newLabel();

  // Process 32 / 16 bytes at a time
#if _supportsAVX2
  a.add(x86::edi, 31);
  a.shr(x86::edi, 5);
  a.vbroadcasti128(x86::ymm0, x86::Mem(constants, 0));
  a.vpbroadcastd(x86::ymm1, x86::Mem(constants, 16));
  a.bind(loop);
  a.vmovdqa(x86::ymm2, x86::ptr(a.zsi()));
  a.add(a.zsi(), 32);
  a.vpshufb(x86::ymm2, x86::ymm2, x86::ymm0);
  a.vpor(x86::ymm2, x86::ymm2, x86::ymm1);
  a.vmovntdq(x86::ptr(a.zdx()), x86::ymm2);
  a.add(a.zdx(), 32);
  a.dec(x86::edi);
  a.jnz(loop);
#else
  a.add(x86::edi, 15);
  a.shr(x86::edi, 4);
  a.movdqa(x86::xmm0, x86::Mem(constants, 0));
  a.movdqa(x86::xmm1, x86::Mem(constants, 16));
  a.bind(loop);
  a.movdqa(x86::xmm2, x86::ptr(a.zsi()));
  a.add(a.zsi(), 16);
  a.pshufb(x86::xmm2, x86::xmm0);
  a.por(x86::xmm2, x86::xmm1);
  a.movntdq(x86::ptr(a.zdx()), x86::xmm2);
  a.add(a.zdx(), 16);
  a.dec(x86::edi);
  a.jnz(loop);
#endif

  // Return
  asmReturn(a);

  // Constants
  a.align(AlignMode::kZero, 16);
  a.bind(constants);
  // 0: shuffleMask
  a.embedUInt8(2);
  a.embedUInt8(1);
  a.embedUInt8(0);
  a.embedUInt8(0xFF);
  a.embedUInt8(6);
  a.embedUInt8(5);
  a.embedUInt8(4);
  a.embedUInt8(0xFF);
  a.embedUInt8(10);
  a.embedUInt8(9);
  a.embedUInt8(8);
  a.embedUInt8(0xFF);
  a.embedUInt8(14);
  a.embedUInt8(13);
  a.embedUInt8(12);
  a.embedUInt8(0xFF);
  a.embedUInt32(0xFF000000, _supportsAVX2 ? 1 : 4); // 1: alpha
}

void yuyvToBGRA(x86::Assembler& a)
{
  Label constants = a.newLabel();
  Label loop = a.newLabel();

  // Process 32 / 16 bytes at a time
#if _supportsAVX2
  a.add(x86::edi, 31);
  a.shr(x86::edi, 5);
  a.vbroadcasti128(x86::ymm5, x86::Mem(constants, 0));
  a.vpbroadcastw(x86::ymm6, x86::Mem(constants, 16));
  a.vpbroadcastw(x86::ymm7, x86::Mem(constants, 18));
  a.vpbroadcastd(x86::ymm8, x86::Mem(constants, 20));
  a.vpbroadcastd(x86::ymm9, x86::Mem(constants, 24));
  a.vpcmpeqb(x86::ymm10, x86::ymm10, x86::ymm10);
  a.bind(loop);
  a.vmovdqa(x86::ymm0, x86::ptr(a.zsi()));
  a.add(a.zsi(), 32);
  a.vpsrlw(x86::ymm1, x86::ymm0, 8);
  a.vpsubw(x86::ymm1, x86::ymm1, x86::ymm6); // YMM1 is now 16-bit UV
  a.vpand(x86::ymm0, x86::ymm0, x86::ymm7); // YMM0 is now 16-bit Y
  a.vpmulhrsw(x86::ymm2, x86::ymm1, x86::ymm8);
  a.vpsllw(x86::ymm2, x86::ymm2, 1); // YMM2 is now 16-bit BR without luminance-shift
  a.vpunpckhwd(x86::ymm3, x86::ymm0, x86::ymm0);
  a.vpunpckhdq(x86::ymm4, x86::ymm2, x86::ymm2);
  a.vpaddw(x86::ymm3, x86::ymm3, x86::ymm4); // YMM3 is now 16-bit BR1
  a.vpunpcklwd(x86::ymm4, x86::ymm0, x86::ymm0);
  a.vpunpckldq(x86::ymm2, x86::ymm2, x86::ymm2);
  a.vpaddw(x86::ymm2, x86::ymm2, x86::ymm4); // YMM2 is now 16-bit BR0
  a.vpackuswb(x86::ymm2, x86::ymm2, x86::ymm3); // YMM2 is now 8-bit BR
  a.vpmulhrsw(x86::ymm1, x86::ymm1, x86::ymm9);
  a.vphaddw(x86::ymm1, x86::ymm1, x86::ymm1);
  a.vpshufb(x86::ymm1, x86::ymm1, x86::ymm5);
  a.vpsubw(x86::ymm0, x86::ymm0, x86::ymm1); // YMM0 is now 16-bit G
  a.vpackuswb(x86::ymm0, x86::ymm0, x86::ymm0);
  a.vpunpcklbw(x86::ymm0, x86::ymm0, x86::ymm10); // YMM0 is now 8-bit GA
  a.vpunpcklbw(x86::ymm1, x86::ymm2, x86::ymm0); // YMM1 is now: BGRA0 BGRA1 BGRA2 BGRA3 BGRA8 BGRA9 BGRA10 BGRA11
  a.vpunpckhbw(x86::ymm2, x86::ymm2, x86::ymm0); // YMM2 is now: BGRA4 BGRA5 BGRA6 BGRA7 BGRA12 BGRA13 BGRA14 BGRA15
  a.vperm2i128(x86::ymm0, x86::ymm1, x86::ymm2, 2 << 4); // YMM0 is now BGRA0 BGRA1 BGRA2 BGRA3 BGRA4 BGRA5 BGRA6 BGRA7
  a.vperm2i128(x86::ymm1, x86::ymm1, x86::ymm2, 1 | (3 << 4)); // YMM1 is now BGRA8 BGRA9 BGRA10 BGRA11 BGRA12 BGRA13 BGRA14 BGRA15
  a.vmovntdq(x86::ptr(a.zdx()), x86::ymm0);
  a.vmovntdq(x86::Mem(a.zdx(), 32), x86::ymm1);
  a.add(a.zdx(), 64);
  a.dec(x86::edi);
  a.jnz(loop);
#else
  a.add(x86::edi, 15);
  a.shr(x86::edi, 4);
  a.movdqa(x86::xmm5, x86::Mem(constants, 0));
  a.movdqa(x86::xmm6, x86::Mem(constants, 16));
  a.movdqa(x86::xmm7, x86::Mem(constants, 16 * 2));
  a.movdqa(x86::xmm8, x86::Mem(constants, 16 * 3));
  a.movdqa(x86::xmm9, x86::Mem(constants, 16 * 4));
  a.pcmpeqb(x86::xmm10, x86::xmm10);
  a.bind(loop);
  a.movdqa(x86::xmm0, x86::ptr(a.zsi()));
  a.add(a.zsi(), 16);
  a.movdqa(x86::xmm1, x86::xmm0);
  a.psrlw(x86::xmm1, 8);
  a.psubw(x86::xmm1, x86::xmm6); // XMM1 is now 16-bit UV
  a.pand(x86::xmm0, x86::xmm7); // XMM0 is now 16-bit Y
  a.movdqa(x86::xmm2, x86::xmm8);
  a.pmulhrsw(x86::xmm2, x86::xmm1);
  a.psllw(x86::xmm2, 1); // XMM2 is now 16-bit BR without luminance-shift
  a.movdqa(x86::xmm3, x86::xmm0);
  a.movdqa(x86::xmm4, x86::xmm2);
  a.punpckhwd(x86::xmm3, x86::xmm3);
  a.punpckhdq(x86::xmm4, x86::xmm4);
  a.paddw(x86::xmm3, x86::xmm4); // XMM3 is now 16-bit BR1
  a.movdqa(x86::xmm4, x86::xmm0);
  a.punpcklwd(x86::xmm4, x86::xmm4);
  a.punpckldq(x86::xmm2, x86::xmm2);
  a.paddw(x86::xmm2, x86::xmm4); // XMM2 is now 16-bit BR0
  a.packuswb(x86::xmm2, x86::xmm3); // XMM2 is now 8-bit BR
  a.pmulhrsw(x86::xmm1, x86::xmm9);
  a.phaddw(x86::xmm1, x86::xmm1);
  a.pshufb(x86::xmm1, x86::xmm5);
  a.psubw(x86::xmm0, x86::xmm1); // XMM0 is now 16-bit G
  a.packuswb(x86::xmm0, x86::xmm0);
  a.punpcklbw(x86::xmm0, x86::xmm10); // XMM0 is now 8-bit GA
  a.movdqa(x86::xmm1, x86::xmm2);
  a.punpcklbw(x86::xmm1, x86::xmm0); // XMM1 is now 8-bit BGRA0
  a.punpckhbw(x86::xmm2, x86::xmm0); // XMM2 is now 8-bit BGRA1
  a.movntdq(x86::ptr(a.zdx()), x86::xmm1);
  a.movntdq(x86::Mem(a.zdx(), 16), x86::xmm2);
  a.add(a.zdx(), 32);
  a.dec(x86::edi);
  a.jnz(loop);
#endif

  // Return
  asmReturn(a);

  // Constants
  a.align(AlignMode::kZero, 16);
  a.bind(constants);
  // 0: shuffleMask
  a.embedUInt8(0);
  a.embedUInt8(1);
  a.embedUInt8(8);
  a.embedUInt8(9);
  a.embedUInt8(2);
  a.embedUInt8(3);
  a.embedUInt8(10);
  a.embedUInt8(11);
  a.embedUInt8(4);
  a.embedUInt8(5);
  a.embedUInt8(12);
  a.embedUInt8(13);
  a.embedUInt8(6);
  a.embedUInt8(7);
  a.embedUInt8(14);
  a.embedUInt8(15);
  a.embedUInt16(128, _supportsAVX2 ? 1 : 8);    // 1: c16_128
  a.embedUInt16(0x00FF, _supportsAVX2 ? 1 : 8); // 2: loMask16
  static constexpr short scaledBCoeff = static_cast<short>(static_cast<float>(1 << 14) / ColorModelConversions::uCoeff);
  static constexpr short scaledRCoeff = static_cast<short>(static_cast<float>(1 << 14) / ColorModelConversions::vCoeff);
  for(size_t i = 0; i < (_supportsAVX2 ? 1 : 4); i++)                    // 3: scaledBRCoeffs16
  {
    a.embedInt16(scaledBCoeff);
    a.embedInt16(scaledRCoeff);
  }
  static constexpr short scaledGCoeffU = static_cast<short>(ColorModelConversions::yCoeffB / (ColorModelConversions::yCoeffG * ColorModelConversions::uCoeff) * static_cast<float>(1 << 15));
  static constexpr short scaledGCoeffV = static_cast<short>(ColorModelConversions::yCoeffR / (ColorModelConversions::yCoeffG * ColorModelConversions::vCoeff) * static_cast<float>(1 << 15));
  for(size_t i = 0; i < (_supportsAVX2 ? 1 : 4); i++)                    // 4: scaledGCoeffs16
  {
    a.embedInt16(scaledGCoeffU);
    a.embedInt16(scaledGCoeffV);
  }
}

DebugImageConverter::DebugImageConverter()
{
  converters[PixelTypes::RGB] = nullptr;
  converters[PixelTypes::BGRA] = nullptr;
  converters[PixelTypes::YUYV] = nullptr;
  converters[PixelTypes::YUV] = static_cast<ConversionFunction>(yuvToBGRA);
  converters[PixelTypes::Grayscale] = static_cast<ConversionFunction>(grayscaledToBGRA);
  converters[PixelTypes::Hue] = reinterpret_cast<ConversionFunction>(hueToBGRA);
  converters[PixelTypes::Binary] = static_cast<ConversionFunction>(binaryToBGRA);
  converters[PixelTypes::Edge2] = static_cast<ConversionFunction>(edge2ToBGRA);
}

DebugImageConverter::~DebugImageConverter()
{
  if(converters[PixelTypes::RGB])
    Global::getAsmjitRuntime().release<ConversionFunction>(converters[PixelTypes::RGB]);
  if(converters[PixelTypes::YUYV])
    Global::getAsmjitRuntime().release<ConversionFunction>(converters[PixelTypes::YUYV]);
}

void DebugImageConverter::convertToBGRA(const DebugImage& src, void* dest)
{
  if(src.type == PixelTypes::BGRA)
    memcpy(dest, src.getView<PixelTypes::BGRAPixel>()[0], src.width * src.height * PixelTypes::pixelSize(PixelTypes::BGRA));
  else
  {
    ASSERT(simdAligned<_supportsAVX2>(dest));
    if(converters[src.type] == nullptr)
    {
      // Check for a valid type before compiling the function
      switch(src.type)
      {
        case PixelTypes::PixelType::RGB:
        case PixelTypes::PixelType::YUV:
        case PixelTypes::PixelType::YUYV:
        case PixelTypes::PixelType::Grayscale:
        case PixelTypes::PixelType::Edge2:
        case PixelTypes::PixelType::Binary:
          break;
        default:
          FAIL("Unknown pixel type.");
      }

      // Initialize assembler
      CodeHolder code;
      code.init(Global::getAsmjitRuntime().environment());
      x86::Assembler a(&code);

      // Emit Prolog
      a.push(a.zbp());
      a.mov(a.zbp(), a.zsp());
      a.push(a.zbx());
#ifdef WINDOWS
      // Windows64
      a.push(a.zdi());
      a.push(a.zsi());
      a.mov(x86::edi, x86::ecx);
      a.mov(a.zsi(), a.zdx());
      a.mov(a.zdx(), x86::r8);
#endif
      switch(src.type)
      {
        case PixelTypes::PixelType::RGB:
          rgbToBGRA(a);
          break;
        case PixelTypes::PixelType::YUV:
          asmReturn(a);
          break;
        case PixelTypes::PixelType::YUYV:
          yuyvToBGRA(a);
          break;
        case PixelTypes::PixelType::Grayscale:
          asmReturn(a);
          break;
        case PixelTypes::PixelType::Edge2:
          asmReturn(a);
          break;
        case PixelTypes::PixelType::Binary:
          asmReturn(a);
          break;
      }

      if(Global::getAsmjitRuntime().add<ConversionFunction>(&converters[src.type], &code))
        converters[src.type] = nullptr;
    }
    if(converters[src.type])
      converters[src.type](static_cast<unsigned int>(src.width * src.height * PixelTypes::pixelSize(src.type)), src.getView<unsigned char>()[0], dest);
  }
}

#else // __arm64__ / __aarch64__

template<bool avx> void rgbToBGRA(const __m_auto_i* const src, const __m_auto_i* const srcEnd, __m_auto_i* const dest)
{
  static const __m_auto_i shuffleMask = _mmauto_setr128_epi8(2, 1, 0, char(0xFF), 6, 5, 4, char(0xFF), 10, 9, 8, char(0xFF), 14, 13, 12, char(0xFF));
  static const __m_auto_i alpha = _mmauto_set1_epi32(0xFF000000);
  __m_auto_i* pDest = dest;
  for(const __m_auto_i* pSrc = src; pSrc < srcEnd; pSrc++)
  {
    _mmauto_storet_si_all<true>(pDest++,
                                _mmauto_or_si_all(
                                  _mmauto_shuffle_epi8(
                                    _mmauto_loadt_si_all<true>(pSrc),
                                    shuffleMask
                                  ),
                                  alpha)
                               );
  }
}

void rgbToBGRA(const PixelTypes::RGBPixel* const src, const PixelTypes::RGBPixel* const srcEnd, PixelTypes::BGRAPixel* const dest)
{
  PixelTypes::BGRAPixel* pDest = dest;
  for(const PixelTypes::RGBPixel* pSrc = src; pSrc < srcEnd; pSrc++, pDest++)
  {
    pDest->b = pSrc->b;
    pDest->g = pSrc->g;
    pDest->r = pSrc->r;
    pDest->a = 0xFF;
  }
}

template<bool avx> void yuyvToBGRA(const __m_auto_i* const src, const __m_auto_i* const srcEnd, __m_auto_i* const dest)
{
  static const __m_auto_i channelMask = _mmauto_set1_epi16(0x00FF);
  static const __m_auto_i c_128 = _mmauto_set1_epi16(128);
  static const __m_auto_i c_0 = _mmauto_setzero_si_all();
  static const __m_auto_i alpha = _mmauto_set1_epi8(static_cast<unsigned char>(0xFF));
  static const __m_auto_i scaledInvUCoeff = _mmauto_set1_epi16(static_cast<short>(static_cast<float>(1 << 14) / ColorModelConversions::uCoeff));
  static const __m_auto_i scaledInvVCoeff = _mmauto_set1_epi16(static_cast<short>(static_cast<float>(1 << 14) / ColorModelConversions::vCoeff));
  static const __m_auto_i scaledGCoeffU = _mmauto_set1_epi16(static_cast<short>(ColorModelConversions::yCoeffB / (ColorModelConversions::yCoeffG * ColorModelConversions::uCoeff) * static_cast<float>(1 << 15)));
  static const __m_auto_i scaledGCoeffV = _mmauto_set1_epi16(static_cast<short>(ColorModelConversions::yCoeffR / (ColorModelConversions::yCoeffG * ColorModelConversions::vCoeff) * static_cast<float>(1 << 15)));
  __m_auto_i* pDest = dest;
  for(const __m_auto_i* pSrc = src; pSrc < srcEnd; pSrc++)
  {
    const __m_auto_i p = _mmauto_loadt_si_all<true>(pSrc);

    const __m_auto_i y = _mmauto_and_si_all(p, channelMask);
    const __m_auto_i uv = _mmauto_sub_epi16(_mmauto_and_si_all(_mmauto_srli_si_all(p, 1), channelMask), c_128);
    __m_auto_i u = _mmauto_packs_epi32(_mmauto_srai_epi32(_mmauto_slli_epi32(uv, 16), 16), c_0);
    u = _mmauto_unpacklo_epi16(u, u);
    __m_auto_i v = _mmauto_packs_epi32(_mmauto_srai_epi32(uv, 16), c_0);
    v = _mmauto_unpacklo_epi16(v, v);

    const __m_auto_i b = _mmauto_correct_256op(_mmauto_packus_epi16(_mmauto_add_epi16(y, _mmauto_slli_epi16(_mmauto_mulhrs_epi16(u, scaledInvUCoeff), 1)), c_0));
    const __m_auto_i g = _mmauto_correct_256op(_mmauto_packus_epi16(_mmauto_sub_epi16(y, _mmauto_add_epi16(_mmauto_mulhrs_epi16(u, scaledGCoeffU), _mmauto_mulhrs_epi16(v, scaledGCoeffV))), c_0));
    const __m_auto_i r = _mmauto_correct_256op(_mmauto_packus_epi16(_mmauto_add_epi16(y, _mmauto_slli_epi32(_mmauto_mulhrs_epi16(v, scaledInvVCoeff), 1)), c_0));

    if(avx)
    {
      __m_auto_i bgra0 = b;
      __m_auto_i tmp = g;
      _mmauto_unpacklohi_epi8(bgra0, tmp);
      __m_auto_i bgra1 = r;
      tmp = alpha;
      _mmauto_unpacklohi_epi8(bgra1, tmp);
      _mmauto_unpacklohi_epi16(bgra0, bgra1);
      _mmauto_storet_si_all<true>(pDest++, bgra0);
      _mmauto_storet_si_all<true>(pDest++, bgra1);
    }
    else
    {
      const __m_auto_i bg = _mmauto_unpacklo_epi8(b, g);
      const __m_auto_i ra = _mmauto_unpacklo_epi8(r, alpha);
      _mmauto_storet_si_all<true>(pDest++, _mmauto_unpacklo_epi16(bg, ra));
      _mmauto_storet_si_all<true>(pDest++, _mmauto_unpackhi_epi16(bg, ra));
    }
  }
}

void yuyvToBGRA(const PixelTypes::YUYVPixel* const src, const PixelTypes::YUYVPixel* const srcEnd, PixelTypes::BGRAPixel* const dest)
{
  PixelTypes::BGRAPixel* pDest = dest;
  for(const PixelTypes::YUYVPixel* pSrc = src; pSrc < srcEnd; pSrc++, pDest++)
  {
    ColorModelConversions::fromYUVToRGB(pSrc->y0, pSrc->u, pSrc->v, pDest->r, pDest->g, pDest->b);
    pDest->a = 0xFF;
    pDest++;
    ColorModelConversions::fromYUVToRGB(pSrc->y1, pSrc->u, pSrc->v, pDest->r, pDest->g, pDest->b);
    pDest->a = 0xFF;
  }
}

template<bool avx> void yuvToBGRA(const __m_auto_i* const src, const __m_auto_i* const srcEnd, __m_auto_i* const dest)
{
  static const __m_auto_i yMask = _mmauto_set1_epi32(0x000000FF);
  static const __m_auto_i channelMask = _mmauto_set1_epi16(0x00FF);
  static const __m_auto_i c_128 = _mmauto_set1_epi16(128);
  static const __m_auto_i c_0 = _mmauto_setzero_si_all();
  static const __m_auto_i alpha = _mmauto_set1_epi8(static_cast<unsigned char>(0xFF));
  static const __m_auto_i scaledInvUCoeff = _mmauto_set1_epi16(static_cast<short>(static_cast<float>(1 << 14) / ColorModelConversions::uCoeff));
  static const __m_auto_i scaledInvVCoeff = _mmauto_set1_epi16(static_cast<short>(static_cast<float>(1 << 14) / ColorModelConversions::vCoeff));
  static const __m_auto_i scaledGCoeffU = _mmauto_set1_epi16(static_cast<short>(ColorModelConversions::yCoeffB / (ColorModelConversions::yCoeffG * ColorModelConversions::uCoeff) * static_cast<float>(1 << 15)));
  static const __m_auto_i scaledGCoeffV = _mmauto_set1_epi16(static_cast<short>(ColorModelConversions::yCoeffR / (ColorModelConversions::yCoeffG * ColorModelConversions::vCoeff) * static_cast<float>(1 << 15)));
  __m_auto_i* pDest = dest;
  for(const __m_auto_i* pSrc = src; pSrc < srcEnd;)
  {
    const __m_auto_i p0 = _mmauto_loadt_si_all<true>(pSrc++);
    const __m_auto_i p1 = _mmauto_loadt_si_all<true>(pSrc++);

    const __m_auto_i y = _mmauto_correct_256op(_mmauto_packs_epi32(_mmauto_and_si_all(_mmauto_srli_epi32(p0, 16), yMask), _mmauto_and_si_all(_mmauto_srli_epi32(p1, 16), yMask)));

    const __m_auto_i uv0 = _mmauto_sub_epi16(_mmauto_and_si_all(_mmauto_srli_si_all(p0, 1), channelMask), c_128);
    const __m_auto_i uv1 = _mmauto_sub_epi16(_mmauto_and_si_all(_mmauto_srli_si_all(p1, 1), channelMask), c_128);
    const __m_auto_i u = _mmauto_correct_256op(_mmauto_packs_epi32(_mmauto_srai_epi32(_mmauto_slli_epi32(uv0, 16), 16), _mmauto_srai_epi32(_mmauto_slli_epi32(uv1, 16), 16)));
    const __m_auto_i v = _mmauto_correct_256op(_mmauto_packs_epi32(_mmauto_srai_epi32(uv0, 16), _mmauto_srai_epi32(uv1, 16)));

    const __m_auto_i b = _mmauto_correct_256op(_mmauto_packus_epi16(_mmauto_add_epi16(y, _mmauto_slli_epi16(_mmauto_mulhrs_epi16(u, scaledInvUCoeff), 1)), c_0));
    const __m_auto_i g = _mmauto_correct_256op(_mmauto_packus_epi16(_mmauto_sub_epi16(y, _mmauto_add_epi16(_mmauto_mulhrs_epi16(u, scaledGCoeffU), _mmauto_mulhrs_epi16(v, scaledGCoeffV))), c_0));
    const __m_auto_i r = _mmauto_correct_256op(_mmauto_packus_epi16(_mmauto_add_epi16(y, _mmauto_slli_epi32(_mmauto_mulhrs_epi16(v, scaledInvVCoeff), 1)), c_0));

    if(avx)
    {
      __m_auto_i bgra0 = b;
      __m_auto_i tmp = g;
      _mmauto_unpacklohi_epi8(bgra0, tmp);
      __m_auto_i bgra1 = r;
      tmp = alpha;
      _mmauto_unpacklohi_epi8(bgra1, tmp);
      _mmauto_unpacklohi_epi16(bgra0, bgra1);
      _mmauto_storet_si_all<true>(pDest++, bgra0);
      _mmauto_storet_si_all<true>(pDest++, bgra1);
    }
    else
    {
      const __m_auto_i bg = _mmauto_unpacklo_epi8(b, g);
      const __m_auto_i ra = _mmauto_unpacklo_epi8(r, alpha);
      _mmauto_storet_si_all<true>(pDest++, _mmauto_unpacklo_epi16(bg, ra));
      _mmauto_storet_si_all<true>(pDest++, _mmauto_unpackhi_epi16(bg, ra));
    }
  }
}

void yuvToBGRA(const PixelTypes::YUVPixel* const src, const PixelTypes::YUVPixel* const srcEnd, PixelTypes::BGRAPixel* const dest)
{
  PixelTypes::BGRAPixel* pDest = dest;
  for(const PixelTypes::YUVPixel* pSrc = src; pSrc < srcEnd; pSrc++, pDest++)
  {
    ColorModelConversions::fromYUVToRGB(pSrc->y, pSrc->u, pSrc->v, pDest->r, pDest->g, pDest->b);
    pDest->a = 0xFF;
  }
}

template<bool avx> void grayscaledToBGRA(const __m_auto_i* const src, const __m_auto_i* const srcEnd, __m_auto_i* const dest)
{
  static const __m_auto_i alpha = _mmauto_set1_epi32(0xFF000000);
  __m_auto_i* pDest = dest;
  for(const __m_auto_i* pSrc = src; pSrc < srcEnd; pSrc++)
  {
    const __m_auto_i p = _mmauto_loadt_si_all<true>(pSrc);

    __m_auto_i pLo = p;
    __m_auto_i pHi = p;
    _mmauto_unpacklohi_epi8(pLo, pHi);

    __m_auto_i pLo2 = pLo;
    __m_auto_i pHi2 = pLo;
    _mmauto_unpacklohi_epi8(pLo2, pHi2);
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pLo2, alpha));
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pHi2, alpha));

    pLo2 = pHi;
    pHi2 = pHi;
    _mmauto_unpacklohi_epi8(pLo2, pHi2);
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pLo2, alpha));
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pHi2, alpha));
  }
}

void grayscaledToBGRA(const PixelTypes::GrayscaledPixel* const src, const PixelTypes::GrayscaledPixel* const srcEnd, PixelTypes::BGRAPixel* const dest)
{
  PixelTypes::BGRAPixel* pDest = dest;
  for(const PixelTypes::GrayscaledPixel* pSrc = src; pSrc < srcEnd; pSrc++, pDest++)
  {
    pDest->r = pDest->g = pDest->b = *pSrc;
    pDest->a = 0xFF;
  }
}

template<bool avx> void binaryToBGRA(const __m_auto_i* const src, const __m_auto_i* const srcEnd, __m_auto_i* const dest)
{
  static const __m_auto_i alpha = _mmauto_set1_epi32(0xFF000000);
  __m_auto_i* pDest = dest;
  for(const __m_auto_i* pSrc = src; pSrc < srcEnd; pSrc++)
  {
    const __m_auto_i p = _mmauto_cmpgt_epi8(_mmauto_loadt_si_all<true>(pSrc), _mmauto_setzero_si_all());

    __m_auto_i pLo = p;
    __m_auto_i pHi = p;
    _mmauto_unpacklohi_epi8(pLo, pHi);

    __m_auto_i pLo2 = pLo;
    __m_auto_i pHi2 = pLo;
    _mmauto_unpacklohi_epi8(pLo2, pHi2);
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pLo2, alpha));
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pHi2, alpha));

    pLo2 = pHi;
    pHi2 = pHi;
    _mmauto_unpacklohi_epi8(pLo2, pHi2);
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pLo2, alpha));
    _mmauto_storet_si_all<true>(pDest++, _mmauto_or_si_all(pHi2, alpha));
  }
}

void binaryToBGRA(const PixelTypes::BinaryPixel* const src, const PixelTypes::BinaryPixel* const srcEnd, PixelTypes::BGRAPixel* const dest)
{
  PixelTypes::BGRAPixel* pDest = dest;
  for(const PixelTypes::BinaryPixel* pSrc = src; pSrc < srcEnd; pSrc++, pDest++)
  {
    pDest->r = pDest->g = pDest->b = *pSrc ? 0xFF : 0;
    pDest->a = 0xFF;
  }
}

void hueToBGRA(const PixelTypes::HuePixel* const src, const PixelTypes::HuePixel* const srcEnd, PixelTypes::BGRAPixel* const dest)
{
  PixelTypes::BGRAPixel* pDest = dest;
  for(const PixelTypes::HuePixel* pSrc = src; pSrc < srcEnd; pSrc++, pDest++)
  {
    ColorModelConversions::fromYUVToRGB(128, static_cast<unsigned char>(static_cast<float>(std::cos(static_cast<float>(*pSrc) * 360_deg / 256.f)) * 128.f + 128.f), static_cast<unsigned char>(static_cast<float>(std::sin(static_cast<float>(*pSrc) * 360_deg / 256.f)) * 128.f + 128.f), pDest->r, pDest->g, pDest->b);
    pDest->a = 0xFF;
  }
}

template<bool avx> void edge2ToBGRA(const __m_auto_i* const src, const __m_auto_i* const srcEnd, __m_auto_i* const dest, const __m_auto_i* const destEnd)
{
  static const __m_auto_i offset = _mmauto_set1_epi8(char(128));
  __m_auto_i* pDest = dest;

  for(const __m_auto_i* pSrc = src; pSrc < srcEnd && pDest < destEnd; pSrc++)
  {
    const __m_auto_i p = _mmauto_loadt_si_all<true>(pSrc);
    const __m_auto_i offsetCorrected = _mmauto_abs_epi8(_mmauto_sub_epi8(p, offset));
    __m_auto_i res0 = _mmauto_slli_epi16(_mmauto_sqrt_epu16<avx>(_mmauto_slli_epi16(_mmauto_maddubs_epi16(offsetCorrected, offsetCorrected), 1)), 8);
    __m_auto_i res1 = p;
    _mmauto_unpacklohi_epi8(res0, res1);
    _mmauto_storet_si_all<true>(pDest++, res0);
    _mmauto_storet_si_all<true>(pDest++, res1);
  }

  yuvToBGRA<avx>(dest, destEnd, dest);
}

void edge2ToBGRA(const PixelTypes::Edge2Pixel* const, const PixelTypes::Edge2Pixel* const, PixelTypes::BGRAPixel* const, const PixelTypes::BGRAPixel* const)
{
  //todo
}

template<bool avx> void typeToBGRA(const void* const src, void* const dest, const PixelTypes::PixelType type, const size_t size)
{
  const __m_auto_i* const pSrc = reinterpret_cast<const __m_auto_i*>(src);
  const __m_auto_i* const srcEnd = reinterpret_cast<const __m_auto_i*>(src) + (size * PixelTypes::pixelSize(type)) / sizeof(__m_auto_i);
  __m_auto_i* pDest = reinterpret_cast<__m_auto_i*>(dest);

  switch(type)
  {
    case PixelTypes::PixelType::RGB:
      rgbToBGRA<avx>(pSrc, srcEnd, pDest);
      break;
    case PixelTypes::PixelType::YUV:
      yuvToBGRA<avx>(pSrc, srcEnd, pDest);
      break;
    case PixelTypes::PixelType::YUYV:
      yuyvToBGRA<avx>(pSrc, srcEnd, pDest);
      break;
    case PixelTypes::PixelType::Grayscale:
      grayscaledToBGRA<avx>(pSrc, srcEnd, pDest);
      break;
    case PixelTypes::PixelType::Hue:
      hueToBGRA(reinterpret_cast<const PixelTypes::HuePixel*>(src), reinterpret_cast<const PixelTypes::HuePixel*>(srcEnd), reinterpret_cast<PixelTypes::BGRAPixel*>(dest));
      break;
    case PixelTypes::PixelType::Edge2:
      edge2ToBGRA<avx>(pSrc, srcEnd, pDest, reinterpret_cast<const __m_auto_i*>(dest) + (size * PixelTypes::pixelSize(PixelTypes::BGRA)) / sizeof(__m_auto_i));
      break;
    case PixelTypes::PixelType::Binary:
      binaryToBGRA<avx>(pSrc, srcEnd, pDest);
      break;
    default:
      FAIL("Unknown pixel type.");
  }

  size_t rest = (size * PixelTypes::pixelSize(type)) % sizeof(__m_auto_i);
  if(rest != 0)
  {
    PixelTypes::BGRAPixel* const ppDest = reinterpret_cast<PixelTypes::BGRAPixel*>(dest) + size - rest;
    switch(type)
    {
      case PixelTypes::PixelType::RGB:
        rgbToBGRA(reinterpret_cast<const PixelTypes::RGBPixel*>(src) + size - rest, reinterpret_cast<const PixelTypes::RGBPixel*>(src) + size, ppDest);
        break;
      case PixelTypes::PixelType::YUV:
        yuvToBGRA(reinterpret_cast<const PixelTypes::YUVPixel*>(src) + size - rest, reinterpret_cast<const PixelTypes::YUVPixel*>(src) + size, ppDest);
        break;
      case PixelTypes::PixelType::YUYV:
        yuyvToBGRA(reinterpret_cast<const PixelTypes::YUYVPixel*>(src) + size - rest, reinterpret_cast<const PixelTypes::YUYVPixel*>(src) + size, ppDest);
        break;
      case PixelTypes::PixelType::Grayscale:
        grayscaledToBGRA(reinterpret_cast<const PixelTypes::GrayscaledPixel*>(src) + size - rest, reinterpret_cast<const PixelTypes::GrayscaledPixel*>(src) + size, ppDest);
        break;
      case PixelTypes::PixelType::Hue:
        hueToBGRA(reinterpret_cast<const PixelTypes::HuePixel*>(src) + size - rest, reinterpret_cast<const PixelTypes::HuePixel*>(src) + size, ppDest);
        break;
      case PixelTypes::PixelType::Edge2:
        edge2ToBGRA(reinterpret_cast<const PixelTypes::Edge2Pixel*>(src) + size - rest, reinterpret_cast<const PixelTypes::Edge2Pixel*>(src) + size, ppDest, reinterpret_cast<PixelTypes::BGRAPixel*>(dest) + size);
        break;
      case PixelTypes::PixelType::Binary:
        binaryToBGRA(reinterpret_cast<const PixelTypes::BinaryPixel*>(src) + size - rest, reinterpret_cast<const PixelTypes::BinaryPixel*>(src) + size, ppDest);
        break;
      default:
        FAIL("Unknown pixel type.");
    }
  }
}

DebugImageConverter::DebugImageConverter()
{
  converters[PixelTypes::RGB] = nullptr; // So it is used
}

DebugImageConverter::~DebugImageConverter() {}

void DebugImageConverter::convertToBGRA(const DebugImage& src, void* dest)
{
  if(src.type == PixelTypes::BGRA)
    memcpy(dest, src.getView<PixelTypes::BGRAPixel>()[0], src.width * src.height * PixelTypes::pixelSize(PixelTypes::BGRA));
  else
  {
    ASSERT(simdAligned<_supportsAVX2>(dest));
    typeToBGRA<_supportsAVX2>(src.getView<PixelTypes::BGRAPixel>()[0], dest, src.type, src.width * src.height);
  }
}

#endif
